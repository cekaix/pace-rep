// Windows: preserve the whole OAuth URL, including its query parameters.
// The upstream SDK 57 opener passes the URL to cmd.exe/start unquoted.
const path = require('node:path');
const fs = require('node:fs');
const { spawn } = require('node:child_process');
// Never record the login flow or its OAuth/session data.
if (process.argv[2] === 'start') require('./runtime-log.cjs').attachRuntimeLog(path.join(__dirname,'work'));
const expoRoot = path.dirname(require.resolve('expo/package.json'));
const cliRoot = path.dirname(require.resolve('@expo/cli/package.json', { paths: [expoRoot] }));
const openPath = path.join(cliRoot, 'build/src/utils/open.js');
const original = require(openPath);
require.cache[openPath].exports = {
  ...original,
  async openBrowserAsync(url) {
    if (process.env.PACE_MANUAL_BROWSER === '1') {
      console.log('PACE_BROWSER_URL=' + url);
      return true;
    }
    const locations = [
      path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Google/Chrome/Application/chrome.exe'),
      path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Google/Chrome/Application/chrome.exe'),
      path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe'),
      path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Microsoft/Edge/Application/msedge.exe'),
    ];
    const browser = locations.find(file => fs.existsSync(file));
    if (!browser) {
      console.log('Ouvre ce lien complet dans ton navigateur : ' + url);
      return false;
    }
    const child = spawn(browser, [url], { shell: false, detached: true, stdio: 'ignore', windowsHide: true });
    await new Promise((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject); });
    child.unref();
    return true;
  },
};
require(path.join(expoRoot, 'bin/cli'));
