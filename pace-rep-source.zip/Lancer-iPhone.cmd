@echo off
cd /d "%~dp0"
set EXPO_NO_TELEMETRY=1
set CI=
if not exist work\expo-temp mkdir work\expo-temp
set TEMP=%~dp0work\expo-temp
set TMP=%TEMP%
title PACE REP - lancement iPhone
echo ETAPE 1/2 : verification de la connexion Expo
call node expo-cli.cjs whoami
if not errorlevel 1 goto launch
echo La connexion va s'ouvrir dans ton navigateur : utilise Continuer avec Google.
echo Reviens ensuite dans CETTE fenetre. Ne la ferme pas.
call node expo-cli.cjs login --browser
if errorlevel 1 (
  echo Connexion non terminee.
  pause
  exit /b 1
)
:launch
echo ETAPE 2/2 : demarrage de PACE REP
echo Garde cette fenetre ouverte et scanne le QR code avec l'appareil photo de ton iPhone.
call node expo-cli.cjs start --go --lan --port 8081
echo Le serveur s'est arrete. Le message utile est affiche juste au-dessus.
pause
