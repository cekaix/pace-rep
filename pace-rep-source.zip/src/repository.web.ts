import { Workout, parseWorkout } from './domain';
const key='pace-rep.workouts.v1';
export async function listWorkouts():Promise<Workout[]> {const value=localStorage.getItem(key);if(value===null)return [];const data=JSON.parse(value);if(!Array.isArray(data))throw new Error('Historique illisible : données conservées.');return data.map(w=>parseWorkout(JSON.stringify(w)));}
export async function saveWorkout(workout:Workout) {parseWorkout(JSON.stringify(workout));const all=await listWorkouts();const next=[workout,...all.filter(w=>w.id!==workout.id)];localStorage.setItem(key,JSON.stringify(next));}
