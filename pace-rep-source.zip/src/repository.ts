// TypeScript fallback; Metro resolves .native.ts or .web.ts for the platform.
export {listWorkouts,saveWorkout} from './repository.web';
