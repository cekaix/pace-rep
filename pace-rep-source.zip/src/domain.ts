export type LoadMode = 'total' | 'perDumbbell' | 'bodyweight' | 'assisted';
export type Exercise = { id:string; name:string; muscle:string; equipment:string; loadMode:LoadMode };
export type SetEntry = { id:string; load:string; reps:string; warmup:boolean; completed:boolean };
export type WorkoutExercise = { id:string; definition:Exercise; sets:SetEntry[] };
export type Workout = { id:string; version:1; startedAt:string; endedAt?:string; status:'draft'|'completed'; title:string; exercises:WorkoutExercise[] };
export const catalog:Exercise[] = [
  {id:'bench',name:'Développé couché',muscle:'Pectoraux',equipment:'Barre',loadMode:'total'},
  {id:'incline',name:'Développé incliné',muscle:'Pectoraux',equipment:'Haltères',loadMode:'perDumbbell'},
  {id:'squat',name:'Squat',muscle:'Quadriceps',equipment:'Barre',loadMode:'total'},
  {id:'legpress',name:'Presse à cuisses',muscle:'Quadriceps',equipment:'Machine',loadMode:'total'},
  {id:'pulldown',name:'Tirage vertical',muscle:'Dos',equipment:'Poulie',loadMode:'total'},
  {id:'row',name:'Rowing barre',muscle:'Dos',equipment:'Barre',loadMode:'total'},
  {id:'deadlift',name:'Soulevé de terre roumain',muscle:'Ischio-jambiers',equipment:'Barre',loadMode:'total'},
  {id:'hipthrust',name:'Hip thrust',muscle:'Fessiers',equipment:'Barre',loadMode:'total'},
  {id:'curl',name:'Curl haltères',muscle:'Biceps',equipment:'Haltères',loadMode:'perDumbbell'},
  {id:'triceps',name:'Extension triceps',muscle:'Triceps',equipment:'Poulie',loadMode:'total'},
  {id:'lateral',name:'Élévations latérales',muscle:'Deltoïdes latéraux',equipment:'Haltères',loadMode:'perDumbbell'},
  {id:'pullup',name:'Tractions',muscle:'Dos',equipment:'Poids du corps',loadMode:'bodyweight'},
  {id:'assisted',name:'Tractions assistées',muscle:'Dos',equipment:'Machine',loadMode:'assisted'},
  {id:'calf',name:'Mollets à la machine',muscle:'Mollets',equipment:'Machine',loadMode:'total'},
  {id:'crunch',name:'Crunch',muscle:'Abdominaux',equipment:'Poids du corps',loadMode:'bodyweight'},
];
export function id() { return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.floor(Math.random()*16);return (c==='x'?r:(r&3)|8).toString(16);}); }
export function newSet():SetEntry { return {id:id(),load:'',reps:'',warmup:false,completed:false}; }
export function loadNumber(value:string) { return value.trim()===''?NaN:Number(value.replace(',','.')); }
export function validSet(s:SetEntry) { return /^\d+$/.test(s.reps) && Number(s.reps)>0 && Number(s.reps)<=1000 && Number.isFinite(loadNumber(s.load)) && loadNumber(s.load)>=0; }
export function workCount(w:Workout) {return w.exercises.reduce((sum,e)=>sum+e.sets.filter(s=>s.completed&&!s.warmup).length,0);}
export function muscleVolumes(workouts:Workout[]) {const totals:Record<string,number>={};for(const w of workouts) for(const e of w.exercises) totals[e.definition.muscle]=(totals[e.definition.muscle]||0)+e.sets.filter(s=>s.completed&&!s.warmup).length;return totals;}
export function tonnage(e:WorkoutExercise) {if(e.definition.loadMode==='assisted'||e.definition.loadMode==='bodyweight')return null;return e.sets.filter(s=>s.completed&&!s.warmup&&validSet(s)).reduce((total,s)=>total+loadNumber(s.load)*Number(s.reps)*(e.definition.loadMode==='perDumbbell'?2:1),0);}
export function thisWeek(workouts:Workout[],now=new Date()) {const start=new Date(now);start.setHours(0,0,0,0);start.setDate(start.getDate()-((start.getDay()+6)%7));return workouts.filter(w=>w.status==='completed'&&new Date(w.startedAt)>=start&&new Date(w.startedAt)<=now);}
export function parseWorkout(value:string):Workout {
  const w=JSON.parse(value);
  if(!w||w.version!==1||typeof w.id!=='string'||typeof w.title!=='string'||!Number.isFinite(Date.parse(w.startedAt))||!['draft','completed'].includes(w.status)||!Array.isArray(w.exercises))throw new Error('Séance illisible : données conservées, chargement interrompu.');
  for(const e of w.exercises){if(!e||typeof e.id!=='string'||!e.definition||typeof e.definition.name!=='string'||typeof e.definition.muscle!=='string'||!['total','perDumbbell','bodyweight','assisted'].includes(e.definition.loadMode)||!Array.isArray(e.sets))throw new Error('Exercice illisible.');for(const s of e.sets)if(!s||typeof s.id!=='string'||typeof s.load!=='string'||typeof s.reps!=='string'||typeof s.warmup!=='boolean'||typeof s.completed!=='boolean'||(s.completed&&!validSet(s)))throw new Error('Série illisible.');}
  return w;
}
