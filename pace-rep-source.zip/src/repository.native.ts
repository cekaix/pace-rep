import * as SQLite from 'expo-sqlite';
import { Workout, parseWorkout } from './domain';
let ready:Promise<SQLite.SQLiteDatabase>|undefined;
function database() {return ready??= (async()=>{const db=await SQLite.openDatabaseAsync('pace-rep.db');await db.execAsync('PRAGMA journal_mode = WAL; CREATE TABLE IF NOT EXISTS workouts (id TEXT PRIMARY KEY NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL); PRAGMA user_version = 1;');return db;})();}
export async function listWorkouts():Promise<Workout[]> {const db=await database();return (await db.getAllAsync<{payload:string}>('SELECT payload FROM workouts ORDER BY updated_at DESC')).map(row=>parseWorkout(row.payload));}
export async function saveWorkout(workout:Workout) {const payload=JSON.stringify(workout);parseWorkout(payload);const db=await database();await db.runAsync('INSERT INTO workouts (id,payload,updated_at) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at',workout.id,payload,new Date().toISOString());}
