const fs = require('node:fs');
const path = require('node:path');
let html = fs.readFileSync(path.join(__dirname,'dist/index.html'),'utf8');
html = html.replace('lang="en"','lang="fr"').replace(/<link rel="icon"[^>]*>/,'');
html = html.replace(/<script src="([^"]+)" defer><\/script>/, (_,src)=>'<script>'+fs.readFileSync(path.join(__dirname,'dist',src),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
fs.writeFileSync(path.join(__dirname,'PACE-REP-PC.html'),html);
