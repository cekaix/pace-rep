const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, 'dist');
const types = { '.html': 'text/html', '.js':'application/javascript', '.css':'text/css', '.png':'image/png', '.ico':'image/x-icon', '.json':'application/json' };
http.createServer((req,res)=>{
  const name = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  const file = path.resolve(root, '.' + (name === '/' ? '/index.html' : name));
  if (!file.startsWith(root + path.sep)) { res.writeHead(403);res.end();return; }
  fs.readFile(file,(error,data)=>{
    if(error){res.writeHead(404);res.end('Introuvable');return;}
    res.setHeader('Content-Type',types[path.extname(file)] || 'application/octet-stream');
    res.end(data);
  });
}).listen(4173,'0.0.0.0',()=>console.log('PACE / REP : http://localhost:4173'));
