@echo off
cd /d "%~dp0"
start "" "%~dp0PACE-REP-PC.html"
