const fs = require('node:fs');
const path = require('node:path');
function attachRuntimeLog(folder) {
  fs.mkdirSync(folder, {recursive:true});
  const file = path.join(folder,'expo-runtime.log');
  fs.appendFileSync(file, '\n--- PACE / REP start ' + new Date().toISOString() + ' ---\n');
  for (const stream of [process.stdout,process.stderr]) {
    const original = stream.write;
    stream.write = function(chunk,...args) {
      try { fs.appendFileSync(file, String(chunk).replace(/\u001b\[[0-9;?]*[A-Za-z]/g,'')); } catch {}
      return original.call(this,chunk,...args);
    };
  }
}
module.exports = {attachRuntimeLog};
